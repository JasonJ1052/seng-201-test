import timeit

import birds_counter as mine
import birds_gpt as gpt
import birds_gpt_eff as gpt_eff


for filename in ['birds_empty.txt', 'birds_small.txt', 'birds_large.txt', 'birds_huge.txt']:
    print('-' * 10)
    print(f'Efficiency on {filename}. Running each algorithm 5 times and taking the average.')
    for algo in [mine, gpt, gpt_eff]:
        # This timeit code runs each evaluation 5 times and takes the average time to finish.
        runtime = timeit.timeit(lambda: algo.count_birds(filename), number=5)
        print(f'\t{algo.__name__}: {runtime:.3f} seconds')


