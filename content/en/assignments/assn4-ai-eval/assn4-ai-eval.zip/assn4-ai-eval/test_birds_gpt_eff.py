# this is the unit test of the program file birds_counter.py
import birds_gpt_eff as birds_counter
import pytest

def test_count_birds_empty():
    assert birds_counter.count_birds('birds_empty.txt') == {}


def test_count_birds_small():
    expected = {
        "White-eared Hummingbird": 2,
        "Red-shouldered Blackbird": 2,
        "Townsend's Solitaire": 4,
        "Yellow-fronted Canary": 4,
        "Chestnut-fronted Macaw": 3,
        "Belted Kingfisher": 1,
        "Common Moorhen": 2,
        "Gray-breasted Martin": 3,
        "Harris's Sparrow": 3,
        "Gray-crowned Yellowthroat": 1
    }

    assert birds_counter.count_birds('birds_small.txt') == expected

def test_count_birds_large() :
    expected = {
        "White-winged Becard": 66598,
        "Olivaceous Woodcreeper": 66625,
        "Zapata Rail": 66565,
        "Black-cowled Oriole": 66514,
        "Mexican Violetear": 66460,
        "Ferruginous Pygmy-Owl": 66663,
        "Fork-tailed Swift": 66429,
        "Yellow-backed Oriole": 66400,
        "Blackburnian Warbler": 66875,
        "Red-breasted Sapsucker": 66629,
        "White-collared Swift": 66691,
        "Flame-throated Warbler": 67061,
        "Wedge-tailed Sabrewing": 66952,
        "Hooded Warbler": 66656,
        "Red-billed Tropicbird": 66882
    }

    assert birds_counter.count_birds('birds_large.txt') == expected

def test_count_birds_huge():
    expected = {
        "Black-cowled Oriole": 666236,
        "Mexican Violetear": 666134,
        "White-winged Becard": 666065,
        "Blackburnian Warbler": 667501,
        "Red-billed Tropicbird": 667483,
        "Zapata Rail": 666100,
        "Fork-tailed Swift": 665701,
        "Yellow-backed Oriole": 667469,
        "Ferruginous Pygmy-Owl": 665962,
        "Flame-throated Warbler": 667654,
        "Red-breasted Sapsucker": 666037,
        "Hooded Warbler": 667425,
        "Wedge-tailed Sabrewing": 666865,
        "Olivaceous Woodcreeper": 667764,
        "White-collared Swift": 665604,
    }
    assert birds_counter.count_birds('birds_huge.txt') == expected

def test_count_birds_bad_filenames():
    with pytest.raises(ValueError) as verr:
        birds_counter.count_birds('')

    with pytest.raises(ValueError) as verr:
        birds_counter.count_birds('a.txt.exe')

def test_count_birds_bad_files():    
    with pytest.raises(FileNotFoundError) as ferr:
        birds_counter.count_birds('noexisto.txt')
    
    with pytest.raises(UnicodeDecodeError) as uerr:
        birds_counter.count_birds('bad.txt')
    