## Paste the count_birds() function from ChatGPT below
