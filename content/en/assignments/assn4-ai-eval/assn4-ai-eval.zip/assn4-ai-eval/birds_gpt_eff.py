## Paste the "efficient" count_birds() function from ChatGPT below
