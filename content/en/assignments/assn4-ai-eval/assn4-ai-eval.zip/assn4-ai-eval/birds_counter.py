def count_birds(filename):
    # This function's job is to compute a dictionary of bird species and counts
    # It raises an exception if the filename 
    #   - does not end in .txt
    #   - if the file is not found
    #   - if the file is in a bad text format

    filename = filename.strip()  # removes any leading or trailing whitespace

    if not filename.endswith('.txt'):
        raise ValueError("You need to enter a valid filename ending in .txt")

    birds = {}

    with open(filename) as input_file:
        for line in input_file:
            name = line.strip()  # strip \n at the end of the line
            if name in birds:
                birds[name] += 1
            else:
                birds[name] = 1
    
    return birds

